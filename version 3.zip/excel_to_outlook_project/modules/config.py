"""
config.py — shared constants used across every module.
Change values here rather than hunting through the pipeline.
"""

DEFAULT_UNIT_COLUMN = "Unit"
DEFAULT_SUMMARY_PATTERN = r"summary|sum"
DEFAULT_OUTPUT_DIR = "./split_output"

# Sample recipients used for any unit missing from a real --recipients CSV.
# Rotated in order, so the pipeline is fully testable before real
# addresses are available.
SAMPLE_RECIPIENTS = [
    {"to": "abc@company.com", "cc": "manager1@company.com"},
    {"to": "avd@company.com", "cc": "manager1@company.com"},
    {"to": "xyz@company.com", "cc": "manager2@company.com"},
    {"to": "def@company.com", "cc": "manager2@company.com"},
]

# Inline CSS for the HTML summary table (kept simple — Outlook strips
# unsupported CSS, so styling is inline per-tag rather than in a <style> block).
TABLE_CSS = (
    "border-collapse:collapse; font-family:Calibri,Arial,sans-serif; "
    "font-size:13px; margin:8px 0 20px 0;"
)
TH_CSS = (
    "border:1px solid #999; background-color:#305496; color:#ffffff; "
    "padding:6px 10px; text-align:left;"
)
TD_CSS = "border:1px solid #ccc; padding:6px 10px;"
