"""
email_body.py — one job: turn a unit's summary DataFrame(s) into an
email body — a real HTML table (not a text dump) plus a plain-text
fallback for clients that can't render HTML.
"""

import pandas as pd

from .config import TABLE_CSS, TH_CSS, TD_CSS


def dataframe_to_html_table(df) -> str:
    """Render a DataFrame as a clean, inline-styled HTML table (renders
    correctly in Outlook, which strips <style> blocks but respects inline styles)."""
    headers = "".join(f'<th style="{TH_CSS}">{col}</th>' for col in df.columns)
    rows_html = []
    for _, row in df.iterrows():
        cells = "".join(f'<td style="{TD_CSS}">{"" if pd.isna(v) else v}</td>' for v in row)
        rows_html.append(f"<tr>{cells}</tr>")
    return (
        f'<table style="{TABLE_CSS}"><thead><tr>{headers}</tr></thead>'
        f'<tbody>{"".join(rows_html)}</tbody></table>'
    )


def build_html_body(unit_value, summary_dfs) -> str:
    parts = [f"<p>Hi,</p><p>Please find attached the file for <b>{unit_value}</b>.</p>"]
    for name, df in summary_dfs:
        parts.append(f"<p><b>{name}</b></p>")
        parts.append(dataframe_to_html_table(df))
    parts.append("<p>Regards,</p>")
    return "<html><body>" + "".join(parts) + "</body></html>"


def build_plain_text_body(unit_value, summary_dfs) -> str:
    lines = ["Hi,", "", f"Please find attached the file for {unit_value}.", ""]
    for name, df in summary_dfs:
        lines.append(f"--- {name} ---")
        lines.append(df.to_string(index=False))
        lines.append("")
    lines.append("Regards,")
    return "\n".join(lines)
