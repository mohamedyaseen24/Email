"""
outlook_draft.py — one job: create a REAL Outlook draft (with a working
Send button, saved into your Drafts folder) via COM automation.

This only works when:
  - You're on Windows
  - Desktop Outlook is installed and signed into your mailbox
  - pywin32 is installed (pip install pywin32)

If any of that isn't true (e.g. testing on Mac/Linux, or browser-only
Outlook access with no desktop app), create_outlook_draft() returns False
and the caller should fall back to eml_writer.write_eml_draft() instead,
which works everywhere but opens as a read-only-looking message rather
than a live draft.
"""

from pathlib import Path


def create_outlook_draft(unit_value, recipient, subject, html_body, attachment_path: Path) -> bool:
    """Creates and SAVES (never sends) a real Outlook draft item.
    Returns True on success, False if Outlook COM automation isn't available
    or fails for any reason — caller should fall back to an .eml file."""
    try:
        import win32com.client
    except ImportError:
        print("  [!] pywin32 not installed / not on Windows -> cannot create a live Outlook draft")
        return False

    try:
        try:
            # gencache builds/uses a cached type library and is more resilient
            # than a bare Dispatch() call on machines with a fresh pywin32 install.
            outlook = win32com.client.gencache.EnsureDispatch("Outlook.Application")
        except Exception:
            outlook = win32com.client.Dispatch("Outlook.Application")

        mail = outlook.CreateItem(0)  # 0 = olMailItem
        mail.Subject = subject
        mail.To = recipient["to"]
        if recipient.get("cc"):
            mail.CC = recipient["cc"]
        mail.HTMLBody = html_body
        mail.Attachments.Add(str(Path(attachment_path).resolve()))
        mail.Save()  # saves into the Drafts folder — does NOT send
        return True
    except Exception as e:
        print(f"  [!] Outlook COM automation failed for '{unit_value}': {e}")
        if "Invalid class string" in str(e) or "-2147221005" in str(e):
            print(
                "      -> Windows can't find Outlook registered as a COM app. Likely fixes:\n"
                "         1) Confirm desktop Outlook (not just Outlook on the web) is installed and has been opened at least once.\n"
                "         2) Run: pip install --upgrade pywin32\n"
                "         3) Then run (as that same Python): python -m win32com.client.combrowse   (or)\n"
                "            python Scripts\\pywin32_postinstall.py -install   (run as Administrator)\n"
                "         4) Test directly: python -c \"import win32com.client as w; w.gencache.EnsureDispatch('Outlook.Application')\""
            )
        return False
