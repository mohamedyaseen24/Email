"""
eml_writer.py — one job: write a standalone .eml file as a fallback when
a real Outlook draft can't be created (no Windows/desktop Outlook/pywin32).

.eml opens in most mail clients but typically as a message you can Reply/
Forward rather than an editable, sendable draft — see outlook_draft.py
for the version with a real Send button.
"""

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path

from .splitter import safe_filename


def write_eml_draft(unit_value, recipient, subject, html_body, plain_body, attachment_path: Path, email_dir: Path) -> Path:
    msg = MIMEMultipart()
    msg["Subject"] = subject
    msg["To"] = recipient["to"]
    if recipient.get("cc"):
        msg["Cc"] = recipient["cc"]

    alt = MIMEMultipart("alternative")
    alt.attach(MIMEText(plain_body, "plain"))
    alt.attach(MIMEText(html_body, "html"))
    msg.attach(alt)

    with open(attachment_path, "rb") as f:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(f.read())
    encoders.encode_base64(part)
    part.add_header("Content-Disposition", f'attachment; filename="{attachment_path.name}"')
    msg.attach(part)

    email_dir.mkdir(parents=True, exist_ok=True)
    eml_path = email_dir / f"{safe_filename(unit_value)}.eml"
    with open(eml_path, "wb") as f:
        f.write(msg.as_bytes())
    return eml_path
