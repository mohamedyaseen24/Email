"""
recipients.py — one job: figure out who each unit's email should go to.

Reads an optional CSV or Excel file (columns: Unit,To,CC) — extension is
auto-detected. Any unit missing from it falls back to a rotating pool of
sample addresses, so the pipeline is fully testable before real
addresses exist.
"""

import csv
from pathlib import Path

import pandas as pd

from .config import SAMPLE_RECIPIENTS


def load_recipient_mapping(path: Path, unit_column_name: str = "Unit") -> dict:
    path = Path(path)
    mapping = {}
    target = unit_column_name.strip().lower()

    if path.suffix.lower() in (".xlsx", ".xls"):
        df = pd.read_excel(path, dtype=str).fillna("")
        cols = {str(c).strip().lower(): c for c in df.columns}
        unit_col = cols.get(target) or cols.get("unit")
        to_col = cols.get("to")
        cc_col = cols.get("cc")
        if not unit_col or not to_col:
            raise ValueError(
                f"'{path.name}' must have a '{unit_column_name}' (or 'Unit') column and a 'To' column. "
                f"Found: {list(df.columns)}"
            )
        for _, row in df.iterrows():
            unit = str(row[unit_col]).strip()
            if not unit:
                continue
            mapping[unit.lower()] = {
                "to": str(row[to_col]).strip(),
                "cc": str(row[cc_col]).strip() if cc_col else "",
            }
    else:
        with open(path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            # build a case-insensitive header map for the CSV path too
            fieldmap = {str(h).strip().lower(): h for h in (reader.fieldnames or [])}
            unit_header = fieldmap.get(target) or fieldmap.get("unit")
            to_header = fieldmap.get("to")
            cc_header = fieldmap.get("cc")
            if not unit_header or not to_header:
                raise ValueError(
                    f"'{path.name}' must have a '{unit_column_name}' (or 'Unit') column and a 'To' column. "
                    f"Found: {reader.fieldnames}"
                )
            for row in reader:
                unit = row.get(unit_header, "").strip()
                if not unit:
                    continue
                mapping[unit.lower()] = {
                    "to": row.get(to_header, "").strip(),
                    "cc": row.get(cc_header, "").strip() if cc_header else "",
                }

    return mapping

def resolve_recipient(unit_value, mapping: dict, sample_index: int):
    """Returns (recipient_dict, next_sample_index)."""
    if mapping:
        entry = mapping.get(str(unit_value).strip().lower())
        if entry and entry["to"]:
            return entry, sample_index
    sample = SAMPLE_RECIPIENTS[sample_index % len(SAMPLE_RECIPIENTS)]
    print(f"  [!] no real mapping for '{unit_value}' -> using sample recipient {sample['to']}")
    return sample, sample_index + 1


def write_recipient_template(units: list, mapping: dict, output_dir: Path) -> Path:
    """Writes recipient_mapping_template.csv: every real unit name next to
    whichever recipient (real or sample) was resolved for it — ready to edit."""
    template_path = output_dir / "recipient_mapping_template.csv"
    idx = 0
    with open(template_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Unit", "To", "CC"])
        for unit in units:
            entry, idx = resolve_recipient(unit, mapping, idx)
            writer.writerow([unit, entry["to"], entry["cc"]])
    return template_path


def resolve_recipient(unit_value, mapping: dict, sample_index: int):
    """Returns (recipient_dict, next_sample_index)."""
    if mapping:
        entry = mapping.get(str(unit_value).strip().lower())
        if entry and entry["to"]:
            return entry, sample_index
    sample = SAMPLE_RECIPIENTS[sample_index % len(SAMPLE_RECIPIENTS)]
    print(f"  [!] no real mapping for '{unit_value}' -> using sample recipient {sample['to']}")
    return sample, sample_index + 1


def write_recipient_template(units: list, mapping: dict, output_dir: Path) -> Path:
    """Writes recipient_mapping_template.csv: every real unit name next to
    whichever recipient (real or sample) was resolved for it — ready to edit."""
    template_path = output_dir / "recipient_mapping_template.csv"
    idx = 0
    with open(template_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Unit", "To", "CC"])
        for unit in units:
            entry, idx = resolve_recipient(unit, mapping, idx)
            writer.writerow([unit, entry["to"], entry["cc"]])
    return template_path
