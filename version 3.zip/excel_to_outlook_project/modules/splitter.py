"""
splitter.py — one job: for a given unit, build a new workbook containing
the SAME SET OF SHEETS as the original, each filtered to that unit's rows,
and hand back any summary-sheet tables found along the way.
"""

import re
from pathlib import Path

import pandas as pd

from .unit_finder import find_column


def safe_filename(value: str) -> str:
    text = str(value).strip()
    text = re.sub(r'[\\/*?:"<>|]', "_", text)
    text = re.sub(r"\s+", "_", text)
    return text or "blank"


def is_summary_sheet(sheet_name: str, pattern: str) -> bool:
    return re.search(pattern, sheet_name, re.IGNORECASE) is not None


def build_unit_workbook(unit_value, sheets: dict, unit_column_name: str,
                         summary_pattern: str, output_dir: Path):
    """Writes <unit>.xlsx with every sheet from the original workbook,
    filtered to this unit's rows (sheets without the unit column are copied
    through unchanged; empty matches still get a headers-only sheet, so the
    sheet set always matches the original).

    Returns (xlsx_path, summary_dfs) where summary_dfs is a list of
    (sheet_name, DataFrame) for any summary sheet that had rows for this unit.
    """
    out_path = output_dir / f"{safe_filename(unit_value)}.xlsx"
    summary_dfs = []

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        for name, df in sheets.items():
            col = find_column(df.columns, unit_column_name)

            if col is not None:
                filtered = df[df[col] == unit_value]
            else:
                filtered = df  # no unit column -> copy the sheet through unchanged

            if filtered.empty and col is not None:
                filtered = df.iloc[0:0]  # keep headers-only sheet, preserving sheet set

            filtered.to_excel(writer, sheet_name=name[:31], index=False)

            if is_summary_sheet(name, summary_pattern) and not filtered.empty:
                summary_dfs.append((name, filtered))

    return out_path, summary_dfs
