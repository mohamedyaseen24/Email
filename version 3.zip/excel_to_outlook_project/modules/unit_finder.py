"""
unit_finder.py — one job: scan every worksheet and build the complete,
deduplicated list of unit values, before any splitting happens.
"""


def find_column(columns, name: str):
    """Case-insensitive column lookup. Returns the actual column name, or None."""
    target = name.strip().lower()
    for col in columns:
        if str(col).strip().lower() == target:
            return col
    return None


def collect_all_units(sheets: dict, unit_column_name: str) -> list:
    """Scans every sheet (summary sheets included) and returns the full,
    deduplicated, sorted list of unit values found anywhere in the workbook."""
    units = set()
    for _, df in sheets.items():
        col = find_column(df.columns, unit_column_name)
        if col is not None:
            units.update(df[col].dropna().unique().tolist())
    return sorted(units, key=str)
