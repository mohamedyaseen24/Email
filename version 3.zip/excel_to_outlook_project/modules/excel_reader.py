"""
excel_reader.py — one job: load every sheet of the master workbook into memory.
Nothing is filtered or interpreted here; that happens in later modules.
"""

from pathlib import Path

import pandas as pd


def load_workbook_sheets(input_path: Path) -> dict:
    """Returns {sheet_name: DataFrame} for every sheet, preserving sheet order."""
    xls = pd.ExcelFile(input_path)
    return {name: xls.parse(name) for name in xls.sheet_names}
