import winreg

try:
    winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, "Outlook.Application")
    print("REGISTERED: Outlook.Application exists in the registry.")
    print("-> This points to a pywin32/registration issue, not a missing classic Outlook.")
except FileNotFoundError:
    print("NOT REGISTERED: Outlook.Application does not exist in the registry.")
    print("-> Classic desktop Outlook is not installed/registered on this machine.")
    print("-> If you have Outlook open right now, check Task Manager: is the process")
    print("   named 'OUTLOOK.EXE'? If it's named something else (e.g. 'olk.exe'),")
    print("   you're on 'New Outlook', which does not support this kind of automation at all.")