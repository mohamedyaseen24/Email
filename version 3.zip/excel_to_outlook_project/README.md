# Excel → Outlook Draft Automation

Scans a multi-sheet master Excel workbook for unit names, splits it into
one workbook per unit (same sheet structure), and creates an Outlook
email draft per unit — with the summary rendered as a real HTML table
and, when run on the right machine, a **genuinely editable draft with a
working Send button**.

---

## Read this first: why some drafts open as "Reply/Forward only"

There are two completely different outputs this pipeline can produce,
and they behave very differently in Outlook:

| | Live Outlook Draft | `.eml` file |
|---|---|---|
| How it's made | Script talks directly to a running, signed-in desktop Outlook via COM automation (`modules/outlook_draft.py`) | Script writes a standalone email file to disk (`modules/eml_writer.py`) |
| Where it lives | Directly in your Outlook **Drafts** folder — a real Outlook item | A file sitting in a folder on disk |
| What you see when you open it | A normal, fully editable compose window — edit To/Cc/Subject/Body/attachment freely, click **Send** | Outlook treats it like a received message — only **Reply / Reply All / Forward** are available, no Send button |
| Requirements | **Windows**, desktop Outlook installed and **signed in**, `pywin32` installed | Works on any OS, no Outlook needed at all |

**This is not a bug and not something any code change can fix** — it's
how Outlook treats any `.eml` file, by design. If you've seen a draft
open with only Reply/Forward available, you were looking at the `.eml`
fallback, which only exists so the pipeline still works on machines
without desktop Outlook (e.g. for testing on Mac/Linux, or when you
only have browser-only Outlook access).

**To get a real, editable draft with Send:** run this on a Windows
machine that has desktop Outlook installed and already signed into your
mailbox. The script will then use `--mode outlook` (the default) and
create genuine Drafts-folder items instead of files.

---

## How it works, step by step

1. **Load every sheet** (`modules/excel_reader.py`).
2. **Find all units** (`modules/unit_finder.py`) — scans every sheet for the unit column and builds the complete, deduplicated list before anything is split.
3. **Split per unit** (`modules/splitter.py`) — one workbook per unit, same set of sheets as the original, filtered rows. Also pulls out any Summary-named sheet's data.
4. **Resolve recipients** (`modules/recipients.py`) — uses your CSV if given; falls back to sample addresses for any uncovered unit, and writes an editable `recipient_mapping_template.csv`.
5. **Build the email body** (`modules/email_body.py`) — a real bordered HTML table for the summary, plus a plain-text fallback.
6. **Create the draft**:
   - `modules/outlook_draft.py` — live Outlook draft via COM automation, when available.
   - `modules/eml_writer.py` — automatic `.eml` fallback otherwise.
7. **You review, then send manually** — the script only ever calls `.Save()`, never `.Send()`, in either path.

`main.py` calls these seven steps in order.

---

## 1. One-time setup

1. Install Python 3.10+ ([python.org](https://www.python.org/downloads/)). On Windows, check "Add python.exe to PATH".
2. Install VS Code ([code.visualstudio.com](https://code.visualstudio.com/)) with the Python extension.
3. Unzip this project, open the folder in VS Code (**File → Open Folder**).
4. Open a terminal (**Terminal → New Terminal**) and run:
   ```
   pip install -r requirements.txt
   ```
   On Windows this also installs `pywin32` (needed for live drafts). On Mac/Linux it's skipped automatically.

## 2. Basic run

```
python main.py --input trackers.xlsx --unit-column "Unit"
```

- **Windows with desktop Outlook signed in:** creates real, editable drafts directly in your Drafts folder.
- **Anything else:** automatically writes `.eml` files instead, and says so in the console output.

## 3. With real recipients

```
python main.py --input trackers.xlsx --unit-column "Unit" --recipients recipient_mapping.csv
```

CSV format (`Unit,To,CC` — multiple addresses in one cell, separated by `;`):

```csv
Unit,To,CC
Unit A,lead@company.com; owner@company.com,manager@company.com; finance@company.com
```

Any unit missing from the CSV still gets a sample address (with a console warning) so nothing breaks.

## 4. Forcing the .eml fallback on purpose

Useful for reviewing files before they'd touch your real Drafts folder:

```
python main.py --input trackers.xlsx --unit-column "Unit" --mode eml
```

## 5. Full command reference

| Flag | Required? | Default | Meaning |
|---|---|---|---|
| `--input` | Yes | — | Path to the master `.xlsx` file |
| `--unit-column` | No | `Unit` | Column name to split by (case-insensitive) |
| `--summary-pattern` | No | `summary\|sum` | Regex for detecting summary sheet names |
| `--output` | No | `./split_output` | Output folder |
| `--recipients` | No | none (sample addresses) | CSV with columns `Unit,To,CC` |
| `--mode` | No | `outlook` | `outlook` (live draft, falls back to `.eml`) or `eml` (always `.eml`) |

## Project layout

```
excel_to_outlook_project/
├── main.py
├── requirements.txt
├── README.md
└── modules/
    ├── config.py          # shared constants
    ├── excel_reader.py    # step 1: load every sheet
    ├── unit_finder.py     # step 2: scan all sheets, build the unit list
    ├── splitter.py         # step 3: split per unit, extract summaries
    ├── recipients.py       # step 4: resolve To/CC per unit
    ├── email_body.py       # step 5: HTML table + plain-text body
    ├── outlook_draft.py    # step 6a: live, editable draft via COM (Windows only)
    └── eml_writer.py       # step 6b: .eml fallback (any OS)
```

## Troubleshooting

| Problem | Fix |
|---|---|
| `'python' is not recognized` | Use `py` instead of `python` |
| `ModuleNotFoundError: No module named 'pandas'` | Re-run `pip install -r requirements.txt` |
| `ERROR: no values found in a 'Unit' column` | Check the real column name, pass via `--unit-column` |
| Console says "pywin32 not installed / not on Windows" | Expected on Mac/Linux. On Windows: `pip install pywin32` |
| `Outlook COM automation failed: ...` on Windows | Desktop Outlook must be installed **and already signed in and running** on this machine |
| Draft opens with only Reply/Forward, no Send | You're looking at the `.eml` fallback, not a live draft — see the table at the top of this README |
