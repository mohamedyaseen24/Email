"""
main.py — orchestrates the full pipeline. Each step below is one line
because the actual work lives in modules/, each doing exactly one job:

    excel_reader   -> load every sheet
    unit_finder    -> scan all sheets, build the full unit list
    splitter       -> build one workbook per unit, same sheet set, extract summaries
    recipients     -> resolve To/CC per unit (real mapping, or sample fallback)
    email_body     -> build the HTML table + plain-text body
    outlook_draft  -> create a REAL, editable, sendable Outlook draft
                      (Windows + desktop Outlook + pywin32 only)
    eml_writer     -> fallback .eml file if a live draft can't be created
                      (works everywhere, but opens as Reply/Forward only —
                      NOT an editable draft; see README for why)

USAGE
-----
    python main.py --input trackers.xlsx --unit-column "Unit"

With a real recipient mapping:
    python main.py --input trackers.xlsx --unit-column "Unit" --recipients recipient_mapping.csv

Force the .eml fallback even on a machine with Outlook (e.g. to inspect
files instead of touching your real Outlook Drafts folder):
    python main.py --input trackers.xlsx --unit-column "Unit" --mode eml
"""

import argparse
import sys
from pathlib import Path

from modules.config import DEFAULT_UNIT_COLUMN, DEFAULT_SUMMARY_PATTERN, DEFAULT_OUTPUT_DIR
from modules.excel_reader import load_workbook_sheets
from modules.unit_finder import collect_all_units
from modules.splitter import build_unit_workbook
from modules.recipients import load_recipient_mapping, resolve_recipient, write_recipient_template
from modules.email_body import build_html_body, build_plain_text_body
from modules.outlook_draft import create_outlook_draft
from modules.eml_writer import write_eml_draft


def main():
    parser = argparse.ArgumentParser(
        description="Scan all sheets for units, split, and create Outlook drafts (with a real Send button when possible)."
    )
    parser.add_argument("--input", required=True, help="Path to the master .xlsx file")
    parser.add_argument("--unit-column", default=DEFAULT_UNIT_COLUMN,
                         help=f"Column name to split by (default: '{DEFAULT_UNIT_COLUMN}')")
    parser.add_argument("--summary-pattern", default=DEFAULT_SUMMARY_PATTERN,
                         help="Regex to detect summary sheet names")
    parser.add_argument("--output", default=DEFAULT_OUTPUT_DIR, help="Common output folder")
    parser.add_argument("--recipients", default=None,
                         help="Optional CSV (Unit,To,CC) with real recipient mapping")
    parser.add_argument("--mode", choices=["outlook", "eml"], default="outlook",
                         help="'outlook': try a real, editable Outlook draft first, fall back to .eml if "
                              "unavailable. 'eml': always write .eml files, skip Outlook COM entirely.")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    email_dir = output_dir / "email_drafts"

    # 1. Load every sheet.
    sheets = load_workbook_sheets(input_path)
    print(f"Loaded {len(sheets)} sheet(s): {', '.join(sheets.keys())}")

    # 2. Scan ALL sheets first, build the full unit list.
    units = collect_all_units(sheets, args.unit_column)
    if not units:
        print(f"ERROR: no values found in a '{args.unit_column}' column on any sheet.")
        sys.exit(1)
    print(f"Identified {len(units)} unit(s) across all sheets: {units}")

    # 3. Recipients: load real mapping if given, write an editable template either way.
    mapping = load_recipient_mapping(Path(args.recipients)) if args.recipients else {}
    template_path = write_recipient_template(units, mapping, output_dir)
    print(f"Recipient template written to {template_path}")

    # 4. Per unit: split, extract summary, resolve recipient, create the draft.
    sample_index = 0
    outlook_count = 0
    eml_count = 0

    for unit_value in units:
        xlsx_path, summary_dfs = build_unit_workbook(
            unit_value, sheets, args.unit_column, args.summary_pattern, output_dir
        )
        print(f"  wrote {xlsx_path}")

        recipient, sample_index = resolve_recipient(unit_value, mapping, sample_index)
        subject = f"Summary - {unit_value}"

        created_live_draft = False
        if args.mode == "outlook":
            html_body = build_html_body(unit_value, summary_dfs)
            created_live_draft = create_outlook_draft(unit_value, recipient, subject, html_body, xlsx_path)

        if created_live_draft:
            outlook_count += 1
            print(f"    + live, EDITABLE Outlook draft created (To: {recipient['to']}, Cc: {recipient.get('cc', '')})")
        else:
            html_body = build_html_body(unit_value, summary_dfs)
            plain_body = build_plain_text_body(unit_value, summary_dfs)
            eml_path = write_eml_draft(unit_value, recipient, subject, html_body, plain_body, xlsx_path, email_dir)
            eml_count += 1
            print(f"    + .eml fallback: {eml_path}  (To: {recipient['to']}, Cc: {recipient.get('cc', '')})")

    print(f"\nDone. {outlook_count} live Outlook draft(s), {eml_count} .eml fallback file(s).")
    print(f"All files are in: {output_dir}")
    if outlook_count:
        print("Live drafts are in your Outlook Drafts folder — fully editable, with a real Send button.")
    if eml_count:
        print("Open the .eml files in email_drafts/ to review; they open as Reply/Forward only, not an "
              "editable draft — see README.md for why, and how to get live drafts instead.")


if __name__ == "__main__":
    main()
