"""
recipients.py — one job: figure out who each unit's email should go to.

Reads an optional CSV (columns: Unit,To,CC). Any unit missing from it
falls back to a rotating pool of sample addresses, so the pipeline is
fully testable before real addresses exist.
"""

import csv
from pathlib import Path

from .config import SAMPLE_RECIPIENTS


def load_recipient_mapping(path: Path) -> dict:
    mapping = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            unit = row.get("Unit", "").strip()
            if not unit:
                continue
            mapping[unit.lower()] = {
                "to": row.get("To", "").strip(),
                "cc": row.get("CC", "").strip(),
            }
    return mapping


def resolve_recipient(unit_value, mapping: dict, sample_index: int):
    """Returns (recipient_dict, next_sample_index)."""
    if mapping:
        entry = mapping.get(str(unit_value).strip().lower())
        if entry and entry["to"]:
            return entry, sample_index
    sample = SAMPLE_RECIPIENTS[sample_index % len(SAMPLE_RECIPIENTS)]
    print(f"  [!] no real mapping for '{unit_value}' -> using sample recipient {sample['to']}")
    return sample, sample_index + 1


def write_recipient_template(units: list, mapping: dict, output_dir: Path) -> Path:
    """Writes recipient_mapping_template.csv: every real unit name next to
    whichever recipient (real or sample) was resolved for it — ready to edit."""
    template_path = output_dir / "recipient_mapping_template.csv"
    idx = 0
    with open(template_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Unit", "To", "CC"])
        for unit in units:
            entry, idx = resolve_recipient(unit, mapping, idx)
            writer.writerow([unit, entry["to"], entry["cc"]])
    return template_path
