# Excel → Outlook Draft Automation — README

Splits a multi-sheet master Excel workbook by Unit, extracts any Summary
sheet content, and generates ready-to-open Outlook `.eml` drafts (with
the unit's Excel file attached) — one per unit.

---

## 1. One-time setup

1. Install Python 3.10+ from [python.org](https://www.python.org/downloads/) (Windows: check "Add python.exe to PATH").
2. Install VS Code from [code.visualstudio.com](https://code.visualstudio.com/) and add the Python extension (Extensions panel → search "Python").
3. Put `excel_to_outlook_drafts.py` and your master Excel file in one folder, open that folder in VS Code (**File → Open Folder**).
4. Open a terminal (**Terminal → New Terminal**) and run:
   ```
   pip install pandas openpyxl
   ```

## 2. Basic run (dummy recipients — no mapping file yet)

```
python excel_to_outlook_drafts.py --input trackers.xlsx --unit-column "Unit"
```

This is the fastest way to test the whole pipeline before you have real
email addresses. It cycles through 4 placeholder addresses
(`dummy1@test.com` … `dummy4@test.com`) across your units.

## 3. What you get, every run

Inside `./split_output/` (or wherever `--output` points):

| File | Purpose |
|---|---|
| `<Unit>.xlsx` | One workbook per unit, with all applicable sheets filtered to that unit |
| `recipient_mapping_template.csv` | Auto-generated: every real unit name paired with whatever recipient was used (dummy or real) |
| `email_drafts/<Unit>.eml` | One email per unit — subject, summary text in the body, unit's Excel file attached |

Double-click any `.eml` file to open it as an editable draft in desktop
Outlook. On Outlook for the web, drag the `.eml` into the app (or import
it) once you're testing that path.

## 4. Switching to real recipients

1. Open `recipient_mapping_template.csv` (it already lists every unit name found — you just need to fill in real addresses).
2. Edit the `To` and `CC` columns with the real addresses per unit.
3. Save it (e.g. as `recipient_mapping.csv`), then re-run pointing at it:
   ```
   python excel_to_outlook_drafts.py --input trackers.xlsx --unit-column "Unit" --recipients recipient_mapping.csv
   ```
4. Any unit still missing from that CSV will fall back to a dummy address automatically, and the script will print a warning line so you know exactly which ones to fill in.

## 5. Efficient day-to-day usage

- **Keep one recipient CSV and reuse it.** Once it's filled in with real addresses, you never need to touch it again unless units change — just re-run step 4's command each time you get a new master file.
- **Re-running is fully safe.** Each run overwrites the previous output folder's contents; nothing is sent or modified outside `--output`.
- **Rename your output folder per run** if you want to keep a history, e.g. `--output ./split_output_2026-09-16`.
- **If your summary sheets have unusual names** (not "Summary" or "Sum"), add `--summary-pattern "summary|recap|sum"` with whatever words apply.
- **If your unit column isn't literally named "Unit"** (e.g. "Unit Name"), pass it exactly: `--unit-column "Unit Name"`.

## 6. Full command reference

| Flag | Required? | Default | Meaning |
|---|---|---|---|
| `--input` | Yes | — | Path to the master `.xlsx` file |
| `--unit-column` | No | `Unit` | Column name to split by (case-insensitive) |
| `--summary-pattern` | No | `summary\|sum` | Regex for detecting summary sheet names |
| `--output` | No | `./split_output` | Output folder |
| `--recipients` | No | none (uses dummy addresses) | CSV with columns `Unit,To,CC` |

## Troubleshooting

| Problem | Fix |
|---|---|
| `'python' is not recognized` | Use `py` instead of `python` |
| `ModuleNotFoundError: No module named 'pandas'` | Re-run `pip install pandas openpyxl` |
| `ERROR: no values found in a 'Unit' column` | Check the real column name and pass it via `--unit-column` |
| Summary content missing from an email | Confirm the summary sheet's name actually matches `--summary-pattern` |
| Wrong/no recipient used for a unit | Check that unit's exact spelling matches a row in your `--recipients` CSV (matching is case-insensitive but must match otherwise) |

## What's next (once desktop Outlook access is available)

The `.eml` step can be swapped for direct Outlook Draft creation via
`win32com`, so drafts appear straight in your Outlook Drafts folder
instead of as files you open manually. Ask when you're ready for that
upgrade — the split/summary/recipient logic stays exactly the same.

## Only one time run code with the recipient name

python excel_to_outlook_pipeline.py --input sample_financial_workbook.xlsx --unit-column "Unit Name" --recipients recipient_mapping.csv --output ./split_output
