"""
excel_to_outlook_pipeline.py

FULL PIPELINE, refined order:

  1. SCAN ALL SHEETS FIRST: go through every worksheet in the workbook
     and collect the complete, deduplicated list of unit names before
     any splitting happens.
  2. SPLIT: for each identified unit, build a new workbook containing
     the SAME SET OF SHEETS as the original, each filtered to that
     unit's rows.
  3. STORE: all split workbooks go into one common output folder.
  4. SUMMARY: if a unit's workbook has a summary sheet (name containing
     "summary" or "sum"), its content is pulled into that unit's email
     body.
  5. DRAFT: one .eml draft per unit is created, with the unit's workbook
     attached and the summary (if any) in the body.
  6. RECIPIENTS: real To/CC per unit will be supplied later. For now,
     sample addresses (abc@company.com, avd@company.com, etc.) are
     assigned in rotation so the whole pipeline is testable end to end.
  7. REVIEW: nothing is sent. You open each .eml, review it, and send
     manually.

No Outlook API / Graph / EntraID access is required — this only writes
files for you to review, which also works fine with browser-only
Outlook access during testing.

USAGE
-----
    python excel_to_outlook_pipeline.py --input trackers.xlsx --unit-column "Unit"

Once you have the real recipient list, put it in a CSV (columns:
Unit,To,CC) and run:

    python excel_to_outlook_pipeline.py --input trackers.xlsx --unit-column "Unit" \\
        --recipients recipient_mapping.csv
"""

import argparse
import csv
import re
import sys
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path

import pandas as pd

# Sample recipients used until a real mapping is provided.
SAMPLE_RECIPIENTS = [
    {"to": "abc@company.com", "cc": "manager1@company.com"},
    {"to": "avd@company.com", "cc": "manager1@company.com"},
    {"to": "xyz@company.com", "cc": "manager2@company.com"},
    {"to": "def@company.com", "cc": "manager2@company.com"},
]


# ---------- helpers ----------

def safe_filename(value: str) -> str:
    text = str(value).strip()
    text = re.sub(r'[\\/*?:"<>|]', "_", text)
    text = re.sub(r"\s+", "_", text)
    return text or "blank"


def find_column(columns, name: str):
    target = name.strip().lower()
    for col in columns:
        if str(col).strip().lower() == target:
            return col
    return None


def is_summary_sheet(sheet_name: str, pattern: str) -> bool:
    return re.search(pattern, sheet_name, re.IGNORECASE) is not None


def load_workbook_sheets(input_path: Path):
    xls = pd.ExcelFile(input_path)
    return {name: xls.parse(name) for name in xls.sheet_names}


# ---------- step 1: scan ALL sheets first, build full unit list ----------

def collect_all_units(sheets: dict, unit_column_name: str):
    """Scans every worksheet (summary sheets included) and returns the
    complete, deduplicated, sorted list of unit values found anywhere."""
    units = set()
    for name, df in sheets.items():
        col = find_column(df.columns, unit_column_name)
        if col is not None:
            units.update(df[col].dropna().unique().tolist())
    return sorted(units, key=str)


# ---------- step 2/3: split into one workbook per unit, same sheet set ----------

def build_unit_workbook(unit_value, sheets: dict, unit_column_name: str,
                         summary_pattern: str, output_dir: Path):
    out_path = output_dir / f"{safe_filename(unit_value)}.xlsx"
    summary_texts = []

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        for name, df in sheets.items():
            col = find_column(df.columns, unit_column_name)

            if col is not None:
                filtered = df[df[col] == unit_value]
            else:
                # sheet has no unit column -> keep it as-is (same set of
                # sheets is preserved even when a sheet can't be filtered)
                filtered = df

            if filtered.empty and col is not None:
                # no rows for this unit on this sheet -> still write an
                # empty sheet with headers, to keep the same sheet set
                filtered = df.iloc[0:0]

            filtered.to_excel(writer, sheet_name=name[:31], index=False)

            if is_summary_sheet(name, summary_pattern) and not filtered.empty:
                summary_texts.append(f"--- {name} ---\n{filtered.to_string(index=False)}")

    return out_path, summary_texts


# ---------- step 6: recipients ----------

def load_recipient_mapping(path: Path):
    mapping = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            unit = row.get("Unit", "").strip()
            if not unit:
                continue
            mapping[unit.lower()] = {
                "to": row.get("To", "").strip(),
                "cc": row.get("CC", "").strip(),
            }
    return mapping


def resolve_recipient(unit_value, mapping: dict, sample_index: int):
    if mapping:
        entry = mapping.get(str(unit_value).strip().lower())
        if entry and entry["to"]:
            return entry, sample_index
    sample = SAMPLE_RECIPIENTS[sample_index % len(SAMPLE_RECIPIENTS)]
    print(f"  [!] no real mapping for '{unit_value}' -> using sample recipient {sample['to']}")
    return sample, sample_index + 1


def write_recipient_template(units, mapping: dict, output_dir: Path):
    template_path = output_dir / "recipient_mapping_template.csv"
    idx = 0
    with open(template_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Unit", "To", "CC"])
        for unit in units:
            entry, idx = resolve_recipient(unit, mapping, idx)
            writer.writerow([unit, entry["to"], entry["cc"]])
    return template_path


# ---------- step 5: draft creation ----------

def write_eml_draft(unit_value, recipient, summary_texts, attachment_path: Path, email_dir: Path):
    msg = MIMEMultipart()
    msg["Subject"] = f"Summary - {unit_value}"
    msg["To"] = recipient["to"]
    if recipient.get("cc"):
        msg["Cc"] = recipient["cc"]

    body = f"Hi,\n\nPlease find attached the file for {unit_value}.\n\n"
    if summary_texts:
        body += "Summary:\n\n" + "\n\n".join(summary_texts) + "\n\n"
    body += "Regards,"
    msg.attach(MIMEText(body, "plain"))

    with open(attachment_path, "rb") as f:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(f.read())
    encoders.encode_base64(part)
    part.add_header("Content-Disposition", f'attachment; filename="{attachment_path.name}"')
    msg.attach(part)

    email_dir.mkdir(parents=True, exist_ok=True)
    eml_path = email_dir / f"{safe_filename(unit_value)}.eml"
    with open(eml_path, "wb") as f:
        f.write(msg.as_bytes())
    return eml_path


# ---------- main ----------

def main():
    parser = argparse.ArgumentParser(description="Scan all sheets for units, split, and draft Outlook emails.")
    parser.add_argument("--input", required=True, help="Path to the master .xlsx file")
    parser.add_argument("--unit-column", default="Unit", help="Column name to split by (default: 'Unit')")
    parser.add_argument("--summary-pattern", default=r"summary|sum",
                         help="Regex to detect summary sheet names")
    parser.add_argument("--output", default="./split_output", help="Common output folder")
    parser.add_argument("--recipients", default=None,
                         help="Optional CSV (Unit,To,CC) with real recipient mapping")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    email_dir = output_dir / "email_drafts"

    # Step 1: load every sheet, scan all of them for the full unit list first.
    sheets = load_workbook_sheets(input_path)
    print(f"Loaded {len(sheets)} sheet(s): {', '.join(sheets.keys())}")

    units = collect_all_units(sheets, args.unit_column)
    if not units:
        print(f"ERROR: no values found in a '{args.unit_column}' column on any sheet.")
        sys.exit(1)
    print(f"Identified {len(units)} unit(s) across all sheets: {units}")

    mapping = load_recipient_mapping(Path(args.recipients)) if args.recipients else {}
    template_path = write_recipient_template(units, mapping, output_dir)
    print(f"Recipient template written to {template_path}")

    # Steps 2-5: split, extract summary, draft — per identified unit.
    sample_index = 0
    for unit_value in units:
        xlsx_path, summary_texts = build_unit_workbook(
            unit_value, sheets, args.unit_column, args.summary_pattern, output_dir
        )
        print(f"  wrote {xlsx_path}")

        recipient, sample_index = resolve_recipient(unit_value, mapping, sample_index)
        eml_path = write_eml_draft(unit_value, recipient, summary_texts, xlsx_path, email_dir)
        print(f"    + draft: {eml_path}  (To: {recipient['to']}, Cc: {recipient.get('cc', '')})")

    print(f"\nDone. All files are in: {output_dir}")
    print("Open the .eml files in email_drafts/ to review each draft before sending manually.")


if __name__ == "__main__":
    main()
